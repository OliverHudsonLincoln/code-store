# Generative AI Activity

For instructions see: https://derekfoster1976.github.io/GenAI_WW_Activity/genai_activity.html





